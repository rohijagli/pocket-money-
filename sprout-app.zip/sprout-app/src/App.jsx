import React, { useState, useMemo, useEffect, Component } from "react";
import {
  Leaf, Sprout, Wallet, Plus, Check, X, Clock, Settings,
  Coins, ArrowUpRight, ArrowDownRight, Users, User, RotateCcw,
} from "lucide-react";

// ---------- Design tokens ----------
// Ink:      #1B2B20  (deep forest text)
// Backdrop: #F3F6EE  (pale sprout)
// Moss:     #3F7D4B  (primary green)
// Deep:     #24402B  (parent / dark banner)
// Marigold: #E8A93B  (money accent)
// Clay:     #C96A4C  (warnings / reject)

const displayFont = "'Space Grotesk', system-ui, sans-serif";
const bodyFont = "'Inter', system-ui, sans-serif";
const monoFont = "'IBM Plex Mono', ui-monospace, monospace";
const ink = "#1B2B20";
const bg = "#F3F6EE";

const STORAGE_KEY = "sprout-app-state-v1";

const DEFAULT_STATE = {
  balance: 340,
  day: 0,
  jars: [
    { id: "j1", name: "New Headphones", goal: 1500, saved: 620 },
    { id: "j2", name: "Trip Fund", goal: 3000, saved: 900 },
    { id: "j3", name: "Rainy Day", goal: 1000, saved: 1000 },
  ],
  chores: [
    { id: "c1", title: "Wash the car", reward: 100, status: "open" },
    { id: "c2", title: "Tidy the garage", reward: 150, status: "pending" },
    { id: "c3", title: "Walk the dog (week)", reward: 80, status: "open" },
  ],
  allowance: { amount: 200, frequency: "Weekly", nextInDays: 3 },
  txns: [
    { id: "t1", desc: "Allowance payout", amount: 200, kind: "in" },
    { id: "t2", desc: "Moved to Trip Fund", amount: -100, kind: "out" },
    { id: "t3", desc: "Chore: Vacuumed living room", amount: 60, kind: "in" },
  ],
};

// ---------- Persistence ----------
function loadState() {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULT_STATE;
    const parsed = JSON.parse(raw);
    return { ...DEFAULT_STATE, ...parsed };
  } catch {
    return DEFAULT_STATE;
  }
}

function saveState(state) {
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {
    // storage unavailable (private mode, quota) — app still works, just won't persist
  }
}

// ---------- Error boundary ----------
class ErrorBoundary extends Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }
  static getDerivedStateFromError() {
    return { hasError: true };
  }
  componentDidCatch(error, info) {
    console.error("Sprout crashed:", error, info);
  }
  render() {
    if (this.state.hasError) {
      return (
        <div style={{
          minHeight: "100%", display: "flex", alignItems: "center", justifyContent: "center",
          background: bg, fontFamily: bodyFont, padding: 24,
        }}>
          <div style={{ textAlign: "center", maxWidth: 320 }}>
            <div style={{ fontFamily: displayFont, fontWeight: 700, fontSize: 20, color: ink, marginBottom: 8 }}>
              Something wilted.
            </div>
            <div style={{ color: "#5A6B57", fontSize: 14, marginBottom: 16 }}>
              Sprout ran into a problem. Reloading usually fixes it — your data is saved.
            </div>
            <button
              onClick={() => window.location.reload()}
              style={{
                background: "#3F7D4B", color: "#fff", border: "none", borderRadius: 10,
                padding: "10px 18px", fontWeight: 600, fontSize: 14, cursor: "pointer",
              }}
            >
              Reload
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

// ---------- Plant pot signature element ----------
function PlantPot({ percent, size = 96 }) {
  const p = Math.max(0, Math.min(1, percent));
  const stemH = 10 + p * 46;
  const leafScale = 0.3 + p * 0.9;
  const bloom = p >= 0.999;

  return (
    <svg width={size} height={size} viewBox="0 0 100 100" aria-hidden="true" focusable="false">
      <path d="M30 74 L70 74 L64 96 L36 96 Z" fill="#B9784F" />
      <rect x="27" y="68" width="46" height="8" rx="2" fill="#8C5A3A" />
      <ellipse cx="50" cy="74" rx="19" ry="3" fill="#4A2F1D" />
      <line x1="50" y1="74" x2="50" y2={74 - stemH} stroke="#3F7D4B" strokeWidth="3.5" strokeLinecap="round" />
      {p > 0.15 && (
        <ellipse
          cx={50 - 10 * leafScale} cy={74 - stemH * 0.55}
          rx={9 * leafScale} ry={5 * leafScale}
          fill="#4F9A5C" transform={`rotate(-25 ${50 - 10 * leafScale} ${74 - stemH * 0.55})`}
        />
      )}
      {p > 0.35 && (
        <ellipse
          cx={50 + 10 * leafScale} cy={74 - stemH * 0.72}
          rx={9 * leafScale} ry={5 * leafScale}
          fill="#3F7D4B" transform={`rotate(25 ${50 + 10 * leafScale} ${74 - stemH * 0.72})`}
        />
      )}
      {p > 0.6 && (
        <ellipse
          cx={50 - 9 * leafScale} cy={74 - stemH * 0.92}
          rx={8 * leafScale} ry={4.5 * leafScale}
          fill="#57A863" transform={`rotate(-15 ${50 - 9 * leafScale} ${74 - stemH * 0.92})`}
        />
      )}
      {bloom && (
        <g>
          {[0, 60, 120, 180, 240, 300].map((deg) => (
            <ellipse
              key={deg}
              cx={50 + 7 * Math.cos((deg * Math.PI) / 180)}
              cy={74 - stemH + 7 * Math.sin((deg * Math.PI) / 180)}
              rx="5" ry="3" fill="#E8A93B"
              transform={`rotate(${deg} ${50 + 7 * Math.cos((deg * Math.PI) / 180)} ${74 - stemH + 7 * Math.sin((deg * Math.PI) / 180)})`}
            />
          ))}
          <circle cx="50" cy={74 - stemH} r="4" fill="#C96A4C" />
        </g>
      )}
    </svg>
  );
}

// ---------- Small building blocks ----------
function Pill({ active, children, onClick, icon: Icon }) {
  return (
    <button
      onClick={onClick}
      aria-pressed={active}
      style={{
        display: "flex", alignItems: "center", gap: 6,
        padding: "8px 16px", borderRadius: 999, border: "none",
        cursor: "pointer", fontFamily: bodyFont, fontWeight: 600, fontSize: 14,
        background: active ? "#1B2B20" : "transparent",
        color: active ? "#F3F6EE" : "#1B2B20",
        transition: "background 0.15s ease, color 0.15s ease",
      }}
    >
      {Icon && <Icon size={15} aria-hidden="true" />}
      {children}
    </button>
  );
}

function Card({ children, style }) {
  return (
    <div style={{ background: "#FFFFFF", borderRadius: 18, border: "1px solid #E3E9DA", padding: 20, ...style }}>
      {children}
    </div>
  );
}

function money(n) {
  const sign = n < 0 ? "-" : "";
  return `${sign}₹${Math.abs(n).toFixed(0)}`;
}

function srOnly() {
  return {
    position: "absolute", width: 1, height: 1, padding: 0, margin: -1,
    overflow: "hidden", clip: "rect(0,0,0,0)", whiteSpace: "nowrap", border: 0,
  };
}

// ---------- Main app ----------
function SproutApp() {
  const initial = useMemo(loadState, []);
  const [role, setRole] = useState("teen");
  const [balance, setBalance] = useState(initial.balance);
  const [day, setDay] = useState(initial.day);
  const [jars, setJars] = useState(initial.jars);
  const [chores, setChores] = useState(initial.chores);
  const [allowance, setAllowance] = useState(initial.allowance);
  const [txns, setTxns] = useState(initial.txns);

  const [choreForm, setChoreForm] = useState({ title: "", reward: "" });
  const [jarAddAmount, setJarAddAmount] = useState({});

  useEffect(() => {
    saveState({ balance, day, jars, chores, allowance, txns });
  }, [balance, day, jars, chores, allowance, txns]);

  const pendingChores = useMemo(() => chores.filter((c) => c.status === "pending"), [chores]);

  function logTxn(desc, amount) {
    setTxns((t) => [{ id: `t${Date.now()}${Math.random().toString(36).slice(2, 6)}`, desc, amount, kind: amount >= 0 ? "in" : "out" }, ...t].slice(0, 8));
  }

  function markChoreDone(id) {
    setChores((cs) => cs.map((c) => (c.id === id ? { ...c, status: "pending" } : c)));
  }

  function approveChore(id) {
    const chore = chores.find((c) => c.id === id);
    if (!chore) return;
    setChores((cs) => cs.map((c) => (c.id === id ? { ...c, status: "approved" } : c)));
    setBalance((b) => b + chore.reward);
    logTxn(`Chore paid: ${chore.title}`, chore.reward);
  }

  function rejectChore(id) {
    setChores((cs) => cs.map((c) => (c.id === id ? { ...c, status: "open" } : c)));
  }

  function addChore(e) {
    e.preventDefault();
    const title = choreForm.title.trim();
    const reward = Number(choreForm.reward);
    if (!title || !reward || reward <= 0) return;
    setChores((cs) => [...cs, { id: `c${Date.now()}`, title, reward, status: "open" }]);
    setChoreForm({ title: "", reward: "" });
  }

  function addToJar(jarId) {
    const amt = Number(jarAddAmount[jarId] || 0);
    if (!amt || amt <= 0 || amt > balance) return;
    setJars((js) => js.map((j) => (j.id === jarId ? { ...j, saved: Math.min(j.goal, j.saved + amt) } : j)));
    setBalance((b) => b - amt);
    const jar = jars.find((j) => j.id === jarId);
    logTxn(`Moved to ${jar?.name}`, -amt);
    setJarAddAmount((s) => ({ ...s, [jarId]: "" }));
  }

  function runPayout() {
    setBalance((b) => b + allowance.amount);
    logTxn("Allowance payout", allowance.amount);
    setAllowance((a) => ({ ...a, nextInDays: 7 }));
  }

  function advanceDay() {
    setDay((d) => d + 1);
    setAllowance((a) => {
      const next = a.nextInDays - 1;
      if (next <= 0) {
        setBalance((b) => b + a.amount);
        logTxn("Allowance payout", a.amount);
        return { ...a, nextInDays: 7 };
      }
      return { ...a, nextInDays: next };
    });
  }

  function resetDemoData() {
    if (!window.confirm("Reset Sprout to its starting demo data? This can't be undone.")) return;
    setBalance(DEFAULT_STATE.balance);
    setDay(DEFAULT_STATE.day);
    setJars(DEFAULT_STATE.jars);
    setChores(DEFAULT_STATE.chores);
    setAllowance(DEFAULT_STATE.allowance);
    setTxns(DEFAULT_STATE.txns);
  }

  return (
    <div style={{ fontFamily: bodyFont, background: bg, minHeight: "100vh", color: ink }}>
      <header style={{
        background: role === "parent" ? "#24402B" : bg,
        transition: "background 0.25s ease",
        padding: "18px 24px",
        borderBottom: "1px solid #E3E9DA",
      }}>
        <div className="sprout-header-inner" style={{ maxWidth: 720, margin: "0 auto", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div style={{ background: "#3F7D4B", borderRadius: 10, padding: 7, display: "flex" }}>
              <Sprout size={18} color="#fff" aria-hidden="true" />
            </div>
            <span style={{ fontFamily: displayFont, fontWeight: 700, fontSize: 20, color: role === "parent" ? "#F3F6EE" : ink }}>
              Sprout
            </span>
          </div>
          <nav aria-label="Switch view" style={{ display: "flex", background: role === "parent" ? "#1B2E20" : "#E9EEE1", borderRadius: 999, padding: 4 }}>
            <Pill active={role === "teen"} onClick={() => setRole("teen")} icon={User}>Teen</Pill>
            <Pill active={role === "parent"} onClick={() => setRole("parent")} icon={Users}>Parent</Pill>
          </nav>
        </div>
      </header>

      <main style={{ maxWidth: 720, margin: "0 auto", padding: "24px 20px 60px" }}>
        {role === "teen" ? (
          <TeenView
            balance={balance} jars={jars} chores={chores} allowance={allowance} txns={txns}
            jarAddAmount={jarAddAmount} setJarAddAmount={setJarAddAmount}
            addToJar={addToJar} markChoreDone={markChoreDone}
          />
        ) : (
          <ParentView
            balance={balance} jars={jars} chores={chores} pendingChores={pendingChores}
            allowance={allowance} setAllowance={setAllowance}
            runPayout={runPayout} advanceDay={advanceDay}
            approveChore={approveChore} rejectChore={rejectChore}
            choreForm={choreForm} setChoreForm={setChoreForm} addChore={addChore}
            txns={txns} day={day} resetDemoData={resetDemoData}
          />
        )}
      </main>
    </div>
  );
}

// ---------- Teen view ----------
function TeenView({ balance, jars, chores, allowance, txns, jarAddAmount, setJarAddAmount, addToJar, markChoreDone }) {
  const openChores = chores.filter((c) => c.status === "open");
  const pendingChores = chores.filter((c) => c.status === "pending");

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      <Card style={{ background: "#1B2B20", color: "#F3F6EE", border: "none" }}>
        <div style={{ fontSize: 13, opacity: 0.75, fontWeight: 500 }}>Available to spend</div>
        <div className="sprout-balance-hero" style={{ fontFamily: monoFont, fontSize: 42, fontWeight: 600, marginTop: 4 }}>
          {money(balance)}
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 6, marginTop: 10, fontSize: 13, opacity: 0.8 }}>
          <Clock size={14} aria-hidden="true" />
          Next allowance in {allowance.nextInDays} day{allowance.nextInDays === 1 ? "" : "s"} · {money(allowance.amount)} {allowance.frequency.toLowerCase()}
        </div>
      </Card>

      <section aria-labelledby="jars-heading">
        <SectionTitle icon={Leaf} id="jars-heading">Savings jars</SectionTitle>
        {jars.length === 0 ? (
          <EmptyState text="No savings jars yet. Ask a parent to set one up." />
        ) : (
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(150px, 1fr))", gap: 14 }}>
            {jars.map((jar) => {
              const pct = jar.saved / jar.goal;
              const remaining = Math.max(0, jar.goal - jar.saved);
              return (
                <Card key={jar.id} style={{ textAlign: "center" }}>
                  <PlantPot percent={pct} size={80} />
                  <div style={{ fontWeight: 600, fontSize: 14, marginTop: 6 }}>{jar.name}</div>
                  <div style={{ fontFamily: monoFont, fontSize: 13, color: "#5A6B57", marginTop: 2 }}>
                    {money(jar.saved)} / {money(jar.goal)}
                  </div>
                  {jar.saved < jar.goal ? (
                    <div style={{ display: "flex", gap: 6, marginTop: 10 }}>
                      <label style={srOnly()} htmlFor={`jar-add-${jar.id}`}>Amount to add to {jar.name}</label>
                      <input
                        id={`jar-add-${jar.id}`}
                        type="number"
                        min="1"
                        max={Math.min(balance, remaining)}
                        inputMode="numeric"
                        placeholder="₹"
                        value={jarAddAmount[jar.id] || ""}
                        onChange={(e) => setJarAddAmount((s) => ({ ...s, [jar.id]: e.target.value }))}
                        style={{ width: "100%", border: "1px solid #E3E9DA", borderRadius: 8, padding: "6px 8px", fontFamily: monoFont, fontSize: 12 }}
                      />
                      <button
                        onClick={() => addToJar(jar.id)}
                        aria-label={`Add to ${jar.name}`}
                        disabled={!jarAddAmount[jar.id] || Number(jarAddAmount[jar.id]) > balance}
                        style={{
                          background: "#3F7D4B", border: "none", borderRadius: 8, color: "#fff",
                          padding: "0 10px", cursor: "pointer", flexShrink: 0, opacity: (!jarAddAmount[jar.id] || Number(jarAddAmount[jar.id]) > balance) ? 0.5 : 1,
                        }}
                      >
                        <Plus size={14} aria-hidden="true" />
                      </button>
                    </div>
                  ) : (
                    <div style={{ fontSize: 12, color: "#E8A93B", fontWeight: 700, marginTop: 10 }}>Goal reached! 🌸</div>
                  )}
                </Card>
              );
            })}
          </div>
        )}
      </section>

      <section aria-labelledby="chores-heading">
        <SectionTitle icon={Check} id="chores-heading">Chores</SectionTitle>
        <Card style={{ padding: 8 }}>
          {[...openChores, ...pendingChores].length === 0 ? (
            <EmptyState text="All caught up — nothing to do right now." />
          ) : (
            <>
              {openChores.map((c) => (
                <ChoreRow key={c.id} chore={c} action={<ActionButton onClick={() => markChoreDone(c.id)}>Mark done</ActionButton>} />
              ))}
              {pendingChores.map((c) => (
                <ChoreRow key={c.id} chore={c} action={<Badge>Waiting for approval</Badge>} />
              ))}
            </>
          )}
        </Card>
      </section>

      <ActivityFeed txns={txns} />
    </div>
  );
}

// ---------- Parent view ----------
function ParentView({
  balance, jars, chores, pendingChores, allowance, setAllowance,
  runPayout, advanceDay, approveChore, rejectChore, choreForm, setChoreForm, addChore, txns, day, resetDemoData,
}) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      <Card>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: 10 }}>
          <div>
            <div style={{ fontSize: 13, color: "#5A6B57", fontWeight: 500 }}>Alex's balance</div>
            <div style={{ fontFamily: monoFont, fontSize: 32, fontWeight: 600 }}>{money(balance)}</div>
          </div>
          <button
            onClick={advanceDay}
            style={{ background: "#E9EEE1", border: "none", borderRadius: 10, padding: "8px 14px", fontSize: 13, fontWeight: 600, cursor: "pointer", color: ink }}
          >
            Simulate 1 day →
          </button>
        </div>
      </Card>

      <section aria-labelledby="approvals-heading">
        <SectionTitle icon={Clock} id="approvals-heading">Pending approvals ({pendingChores.length})</SectionTitle>
        <Card style={{ padding: 8 }}>
          {pendingChores.length === 0 ? (
            <EmptyState text="Nothing waiting on you." />
          ) : (
            pendingChores.map((c) => (
              <ChoreRow
                key={c.id}
                chore={c}
                action={
                  <div style={{ display: "flex", gap: 6 }}>
                    <IconButton onClick={() => approveChore(c.id)} bg="#3F7D4B" label={`Approve ${c.title}`}>
                      <Check size={14} color="#fff" aria-hidden="true" />
                    </IconButton>
                    <IconButton onClick={() => rejectChore(c.id)} bg="#C96A4C" label={`Reject ${c.title}`}>
                      <X size={14} color="#fff" aria-hidden="true" />
                    </IconButton>
                  </div>
                }
              />
            ))
          )}
        </Card>
      </section>

      <section aria-labelledby="allowance-heading">
        <SectionTitle icon={Settings} id="allowance-heading">Allowance</SectionTitle>
        <Card>
          <div style={{ display: "flex", gap: 12, flexWrap: "wrap", alignItems: "flex-end" }}>
            <Field label="Amount" htmlFor="allowance-amount">
              <input
                id="allowance-amount"
                type="number"
                min="1"
                value={allowance.amount}
                onChange={(e) => setAllowance((a) => ({ ...a, amount: Math.max(1, Number(e.target.value) || 0) }))}
                style={inputStyle}
              />
            </Field>
            <Field label="Frequency" htmlFor="allowance-frequency">
              <select
                id="allowance-frequency"
                value={allowance.frequency}
                onChange={(e) => setAllowance((a) => ({ ...a, frequency: e.target.value }))}
                style={inputStyle}
              >
                <option>Weekly</option>
                <option>Monthly</option>
              </select>
            </Field>
            <button
              onClick={runPayout}
              style={{ background: "#3F7D4B", color: "#fff", border: "none", borderRadius: 10, padding: "10px 16px", fontWeight: 600, fontSize: 13, cursor: "pointer", display: "flex", alignItems: "center", gap: 6 }}
            >
              <Coins size={15} aria-hidden="true" /> Run payout now
            </button>
          </div>
          <div style={{ fontSize: 12, color: "#7A8A76", marginTop: 10 }}>
            Next automatic payout in {allowance.nextInDays} day{allowance.nextInDays === 1 ? "" : "s"} · simulated day {day}
          </div>
        </Card>
      </section>

      <section aria-labelledby="jars-parent-heading">
        <SectionTitle icon={Leaf} id="jars-parent-heading">Savings jars</SectionTitle>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(150px, 1fr))", gap: 14 }}>
          {jars.map((jar) => (
            <Card key={jar.id} style={{ textAlign: "center" }}>
              <PlantPot percent={jar.saved / jar.goal} size={70} />
              <div style={{ fontWeight: 600, fontSize: 13, marginTop: 6 }}>{jar.name}</div>
              <div style={{ fontFamily: monoFont, fontSize: 12, color: "#5A6B57" }}>{money(jar.saved)} / {money(jar.goal)}</div>
            </Card>
          ))}
        </div>
      </section>

      <section aria-labelledby="add-chore-heading">
        <SectionTitle icon={Plus} id="add-chore-heading">Add a chore</SectionTitle>
        <Card>
          <form onSubmit={addChore} style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            <label style={srOnly()} htmlFor="chore-title">Chore title</label>
            <input
              id="chore-title"
              placeholder="Chore title"
              value={choreForm.title}
              onChange={(e) => setChoreForm((f) => ({ ...f, title: e.target.value }))}
              style={{ ...inputStyle, flex: 2, minWidth: 160 }}
            />
            <label style={srOnly()} htmlFor="chore-reward">Reward amount in rupees</label>
            <input
              id="chore-reward"
              type="number"
              min="1"
              placeholder="Reward ₹"
              value={choreForm.reward}
              onChange={(e) => setChoreForm((f) => ({ ...f, reward: e.target.value }))}
              style={{ ...inputStyle, flex: 1, minWidth: 90 }}
            />
            <button
              type="submit"
              disabled={!choreForm.title.trim() || !choreForm.reward}
              style={{
                background: "#1B2B20", color: "#fff", border: "none", borderRadius: 10,
                padding: "0 16px", fontWeight: 600, fontSize: 13, cursor: "pointer",
                opacity: (!choreForm.title.trim() || !choreForm.reward) ? 0.5 : 1,
              }}
            >
              Add
            </button>
          </form>
        </Card>
      </section>

      <ActivityFeed txns={txns} />

      <button
        onClick={resetDemoData}
        style={{
          alignSelf: "flex-start", background: "none", border: "none", color: "#7A8A76",
          fontSize: 12, cursor: "pointer", display: "flex", alignItems: "center", gap: 5, padding: "4px 0",
        }}
      >
        <RotateCcw size={12} aria-hidden="true" /> Reset demo data
      </button>
    </div>
  );
}

// ---------- Shared bits ----------
function SectionTitle({ icon: Icon, children, id }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 10 }}>
      <Icon size={15} color="#3F7D4B" aria-hidden="true" />
      <h2 id={id} style={{ fontFamily: displayFont, fontWeight: 600, fontSize: 15, margin: 0 }}>{children}</h2>
    </div>
  );
}

function EmptyState({ text }) {
  return <div style={{ padding: 16, textAlign: "center", color: "#7A8A76", fontSize: 14 }}>{text}</div>;
}

function ChoreRow({ chore, action }) {
  return (
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "12px 10px", borderBottom: "1px solid #F0F3EA" }}>
      <div>
        <div style={{ fontWeight: 600, fontSize: 14 }}>{chore.title}</div>
        <div style={{ fontFamily: monoFont, fontSize: 12, color: "#7A8A76" }}>+{money(chore.reward)}</div>
      </div>
      {action}
    </div>
  );
}

function ActionButton({ children, onClick }) {
  return (
    <button onClick={onClick} style={{ background: "#E9EEE1", border: "none", borderRadius: 8, padding: "7px 12px", fontSize: 12, fontWeight: 600, cursor: "pointer", color: "#1B2B20" }}>
      {children}
    </button>
  );
}

function IconButton({ children, onClick, bg, label }) {
  return (
    <button
      onClick={onClick}
      aria-label={label}
      style={{ background: bg, border: "none", borderRadius: 8, width: 28, height: 28, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer" }}
    >
      {children}
    </button>
  );
}

function Badge({ children }) {
  return (
    <span style={{ fontSize: 11, fontWeight: 600, color: "#8C6A2C", background: "#FBF0D9", padding: "4px 10px", borderRadius: 999 }}>
      {children}
    </span>
  );
}

function Field({ label, children, htmlFor }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
      <label htmlFor={htmlFor} style={{ fontSize: 11, color: "#7A8A76", fontWeight: 600 }}>{label}</label>
      {children}
    </div>
  );
}

const inputStyle = {
  border: "1px solid #E3E9DA", borderRadius: 10, padding: "9px 10px",
  fontFamily: bodyFont, fontSize: 13, outline: "none",
};

function ActivityFeed({ txns }) {
  return (
    <section aria-labelledby="activity-heading">
      <SectionTitle icon={Wallet} id="activity-heading">Recent activity</SectionTitle>
      <Card style={{ padding: 8 }}>
        {txns.length === 0 ? (
          <EmptyState text="No activity yet." />
        ) : (
          txns.map((t) => (
            <div key={t.id} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "10px 10px", borderBottom: "1px solid #F0F3EA" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                {t.kind === "in" ? <ArrowDownRight size={15} color="#3F7D4B" aria-hidden="true" /> : <ArrowUpRight size={15} color="#C96A4C" aria-hidden="true" />}
                <span style={{ fontSize: 13, fontWeight: 500 }}>{t.desc}</span>
              </div>
              <span style={{ fontFamily: monoFont, fontSize: 13, fontWeight: 600, color: t.kind === "in" ? "#3F7D4B" : "#C96A4C" }}>
                {t.kind === "in" ? "+" : ""}{money(t.amount)}
              </span>
            </div>
          ))
        )}
      </Card>
    </section>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <SproutApp />
    </ErrorBoundary>
  );
}
